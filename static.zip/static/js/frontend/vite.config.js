import { defineConfig } from 'vite'
import { resolve } from 'path'

export default defineConfig({
  // Root folder: where your index.html lives
  root: '.',

  // Use relative paths for production so it works anywhere
  base: './',

  build: {
    // Output folder for production files
    outDir: resolve(__dirname, '../../../dist'), // project_root/dist
    emptyOutDir: true,

    rollupOptions: {
      // Use index.html as the entry point
      input: {
        main: resolve(__dirname, 'index.html'), 
      },
    },
  },

  server: {
    port: 5173,
    strictPort: true,
    cors: true, // allows Django to load scripts during dev
  },
})
